from django.apps import AppConfig


class SurveillanceConfig(AppConfig):
    name = 'surveillance'
